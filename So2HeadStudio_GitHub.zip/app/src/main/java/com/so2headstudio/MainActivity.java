package com.so2headstudio;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String GAME_PACKAGE = "com.axlebolt.standoff2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView web = new WebView(this);
        web.setBackgroundColor(0xFF090D18);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface
            public void launchGame() {
                runOnUiThread(() -> openGame());
            }
        }, "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void openGame() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(GAME_PACKAGE);
        if (launch != null) {
            startActivity(launch);
        } else {
            Toast.makeText(this, "Standoff 2 yüklü görünmüyor.", Toast.LENGTH_LONG).show();
        }
    }
}
