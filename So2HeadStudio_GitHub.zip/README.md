# So2 Head Studio

Android companion app built with Java + HTML + JavaScript, with GitHub Actions YAML for APK builds.

## Features
- Dark mobile interface
- Head-size slider with an in-app visual preview
- START button opens Standoff 2 if it is installed
- GitHub Actions workflow builds a debug APK

## Important limitation
The slider changes only the sample avatar inside this app. It does not modify Standoff 2, player models, hitboxes, game memory, or online gameplay.

## Build on GitHub
1. Upload the contents of this ZIP to a GitHub repository.
2. Open **Actions**.
3. Run **Build Android APK** or push to `main`.
4. Open the completed workflow run and download the `So2HeadStudio-debug` artifact.

Package launch uses `com.axlebolt.standoff2`. If the installed game uses a different package ID on your device, update `GAME_PACKAGE` in `MainActivity.java`.
